export { defineTranslation as dt } from "./defineTranslation";
export { initI18n, type LanguageMessages } from "./init";
