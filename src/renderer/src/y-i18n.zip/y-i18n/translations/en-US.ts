import { type LanguageMessages } from "../lib";

export default {
    locale: "en-US",
} as const satisfies LanguageMessages;
